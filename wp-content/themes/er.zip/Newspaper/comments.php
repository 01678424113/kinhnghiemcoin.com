<?php

// - Important!
// - For overwriting comments' functionality in child-theme, copy the file 'comments.php' from the
// following theme path (../themes/THEME_NAME/includes/wp_booster/comments.php) to the child-theme root path,
// and NOT this comments.php file you are reading from.

require_once('includes/wp_booster/comments.php');
