<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_hammer',                  "http://demo_content.tagdiv.com/Newspaper_multi/law_firm/hammer.png");

// placeholder images
td_demo_media::add_image_to_media_gallery('td_placeholder_1',           "http://demo_content.tagdiv.com/Newspaper_multi/law_firm/placeholder-1.jpg");