<?php
td_demo_media::add_image_to_media_gallery('concrete-texture',                   "http://demo_content.tagdiv.com/Newspaper_multi/construction/concrete-texture.png");
td_demo_media::add_image_to_media_gallery('logo',                               "http://demo_content.tagdiv.com/Newspaper_multi/construction/logo.png");
td_demo_media::add_image_to_media_gallery('logo@2x',                            "http://demo_content.tagdiv.com/Newspaper_multi/construction/logo@2x.png");
td_demo_media::add_image_to_media_gallery('logo-black',                         "http://demo_content.tagdiv.com/Newspaper_multi/construction/logo-black.png");