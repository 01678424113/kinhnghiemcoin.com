<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/fashion/p3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/Newspaper_6/fashion/p4.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p5',                  "http://demo_content.tagdiv.com/Newspaper_6/fashion/p5.jpg");

//logo
td_demo_media::add_image_to_media_gallery('td_pic_logo_desktop',        'http://demo_content.tagdiv.com/Newspaper_6/fashion/Logo-fashion.png');

