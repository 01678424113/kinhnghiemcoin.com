<?php
// logos
td_demo_media::add_image_to_media_gallery('td_logo_header',             "http://demo_content.tagdiv.com/Newspaper_6/craft_ideas/header-logo.png");
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',      "http://demo_content.tagdiv.com/Newspaper_6/craft_ideas/header-logo@2x.png");
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             "http://demo_content.tagdiv.com/Newspaper_6/craft_ideas/mobile-logo.png");