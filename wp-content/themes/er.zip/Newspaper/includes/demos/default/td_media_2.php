<?php
/**
 * Created by ra on 6/13/2015.
 */
td_demo_media::add_image_to_media_gallery('td_pic_5',                   "http://demo_content.tagdiv.com/Newspaper_6/default_8/5.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_6',                   "http://demo_content.tagdiv.com/Newspaper_6/default_8/6.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_7',                   "http://demo_content.tagdiv.com/Newspaper_6/default_8/7.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_8',                   "http://demo_content.tagdiv.com/Newspaper_6/default_8/8.jpg");