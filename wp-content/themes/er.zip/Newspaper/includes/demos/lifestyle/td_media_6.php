<?php

// logos
td_demo_media::add_image_to_media_gallery('td_logo_header',             "http://demo_content.tagdiv.com/Newspaper_6/lifestyle/lifestyle-magazine-logo.png");
td_demo_media::add_image_to_media_gallery('td_logo_footer',             "http://demo_content.tagdiv.com/Newspaper_6/lifestyle/lifestyle-magazine-logo-mobile.png");
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             "http://demo_content.tagdiv.com/Newspaper_6/lifestyle/lifestyle-magazine-logo-mobile.png");


// other images
td_demo_media::add_image_to_media_gallery('td_lifestyle_footer_bg',       "http://demo_content.tagdiv.com/Newspaper_6/lifestyle/6.jpg");