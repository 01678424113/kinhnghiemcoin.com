<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/book_club/p3.jpg");

//logo
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_6/book_club/header-logo.png');
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',      'http://demo_content.tagdiv.com/Newspaper_6/book_club/header-logo@2x.png');
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             'http://demo_content.tagdiv.com/Newspaper_6/book_club/mobile-logo.png');



