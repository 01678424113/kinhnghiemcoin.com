<?php
/**
 * Created by ra on 6/13/2015.
 */

//hero
td_demo_media::add_image_to_media_gallery('hero_home',          'http://demo_content.tagdiv.com/Newspaper_multi/showcase/td-hero-home.jpg');
td_demo_media::add_image_to_media_gallery('hero_about',         'http://demo_content.tagdiv.com/Newspaper_multi/showcase/td-hero-about.jpg');
td_demo_media::add_image_to_media_gallery('hero_contact',       'http://demo_content.tagdiv.com/Newspaper_multi/showcase/td-hero-contact.jpg');

//placeholder images
td_demo_media::add_image_to_media_gallery('placeholder_1',            'http://demo_content.tagdiv.com/Newspaper_multi/showcase/td-placeholder-1.jpg');