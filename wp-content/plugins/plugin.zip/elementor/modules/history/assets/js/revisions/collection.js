var RevisionModel = require( './model' );

module.exports = Backbone.Collection.extend( {
	model: RevisionModel
} );
